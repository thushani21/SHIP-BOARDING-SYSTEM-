import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;
public class Main {
    //initializing Global components
    public static Scanner scanner = new Scanner(System.in);
    public static String[] cabins = new String[13];

    public static int index = 1;
	public static String no;
    public static String name;

    //method to initialize 12 cabins
    private static void initialise() {
        for (int x = 1; x < 13; x++ ) {
            cabins[x] = "e";
        }
        System.out.println("initialise ");
    }

    //method to add passengers to cabins
    public static void add() {
        boolean c = false;
        do {
            System.out.print("Enter cabin number (1-12) :");
            no = scanner.next();

            try {
                index = Integer.parseInt(no);
                c = true;
            } catch (NumberFormatException e) {
                System.out.println("Enter integers only.....");
            }
        }
        while (!c);


        if (index < 0 || index > 13) {
            System.out.println("Enter Valid Cabin Number :");

        } else {
            if (cabins[index].equals("e")) {
                System.out.println("Enter Valid Cabin Number :");
                System.out.print("Enter the first name of the passenger in cabin no :" + index + " :");
                name = scanner.next();
                cabins[index] = name;

                System.out.println("Passenger details added successfully");


            } else {
                System.out.println("Cabin is Occupied");
            }
        }

    }







    //method to view all cabin details
    public static void view() {
        for (int x = 1; x < cabins.length; x++ ) {
            System.out.println("Cabin " + x + " occupied by " + cabins[x]);
        }
    }

    //method to delete passenger from cabins
    public static void delete() {
        System.out.print("Enter passenger's first name :");
        String passengerName = scanner.next();
        boolean isCustomer = false;
        for (int x = 1; x < cabins.length; x++) {
            if (cabins[x].equals(passengerName)) {
                cabins[x] = "e";

                System.out.println("Passenger's name in cabin number " + x + " successfully deleted");
                isCustomer = true;
                break;
            }
        }
        if (!isCustomer) {          //if the mentioned passenger not available
            System.out.println("Passenger not available");
        }
    }

    //method to view all empty cabins
    public static void empty(){
        int counter=0;
        for (int x = 1; x < cabins.length; x++ ) {
            if (cabins[x].equals("e")){                 //Checks if there are any empty cabin available
                System.out.println("cabin " + x + " is empty");
            } else counter++;
        }if (counter == 12)
            System.out.println("There are no empty cabins");
    }

    //method to find passenger details
    public static void find() {
        System.out.print("Enter the passenger's name: ");
        String passengerName = scanner.next();
        boolean isCustomer = false;
        for (int x = 1; x < cabins.length; x++) {
            if (cabins[x].equals(passengerName)) {
                System.out.println(passengerName + " is found in cabin number " + x );
                isCustomer = true;
                break;
            }
        }
        if (!isCustomer) {
            System.out.println("Passenger not available");
        }
    }

    //method to create a text file and store cabin details
    public static void store() throws IOException {
        File Storage = new File("passengerData.txt");
        Storage.createNewFile();  //A new file is created using the method
        FileWriter writer = new FileWriter(Storage.getName());
        for(int x = 1; x<cabins.length; x++){
            writer.write( cabins[x] + "\n");
        }
        writer.close();
        System.out.println("File saved");           //Message appears once all data is saved
    }

    //method to load cabin details from text file
    public static void load() throws IOException {
        int index = 1;
        File Storage = new File("passengerData.txt");
        Scanner reader = new Scanner(Storage);
        while (reader.hasNextLine()) {
            String data = reader.nextLine();
            String data1 = reader.nextLine();
            String data2 = reader.nextLine();
            cabins[index]= data;  //data taken from file is stored to array
            index++;
        }
        reader.close();
        System.out.println("Loaded successfully");  //Message appears once all data is loaded
    }

    //method to view passenger name in alphabetical order
    public static void order(){
        for (int i = 1; i <cabins.length; i++)
        {
            for (int j = i + 1; j < cabins.length; j++)
            {
                if (cabins[i].compareTo(cabins[j]) > 1) //compares two different elements of the array at a time
                {
                    String temp = cabins[i];
                    cabins[i] = cabins[j];
                    cabins[j] = temp;  //rearranged in a way to make sure it is in alphabetical order
                }
            }
        }
        for (int x = 1; x < cabins.length; x++) {
            if(!cabins[x].equals("e"))
                System.out.println("-"+ cabins[x]);
        }
    }

    //method to print main menu and return user option
    public static String menu() {
        System.out.println("\n||||||||||||| Welcome to the Cruise ship |||||||||||||\n");
        System.out.println("A - Add new Passenger");
        System.out.println("E - Display Empty Cabins");
        System.out.println("V - View All Cabins");
        System.out.println("D - Delete Passenger From Cabin");
        System.out.println("F - Find cabin from customer name");
        System.out.println("S - Store program data into file");
        System.out.println("L - Load program data from file");
        System.out.println("O - View passengers ordered alphabetically by name");
        System.out.println("Q - End the program");
        System.out.print("\n Select an option: ");//gets the user scanner
        String option = scanner.next().toLowerCase();

        return option;
    }

    public static void main(String[] args) {

        initialise();                //initialize method is called
        boolean cont = true;            //boolean to keep the program running until the user wants to stop
        while (cont) {
            String option = menu();

            switch (option) {
                case "v":
                    view();
                    break;
                case "e":
                    empty();
                    break;
                case "a":
                    add();
                    break;
                case "d":
                    delete();
                    break;
                case "f":
                    find();
                    break;
                case "s":
                    try {
                        store();
                    } catch (IOException e) {
                        e.printStackTrace();  //Method passed to manage exceptions and error
                    }
                    break;
                case "l":
                    try {
                        load(); //The method load is called
                    } catch (IOException e) {
                        e.printStackTrace();  //Method passed to manage exceptions and error
                    }
                    break;
                case "o":
                    order();
                    break;
				case "q":
					System.out.println("Program ends.........");
                    System.exit(0);
                    break;
                default://when the user enters something other than the options given
                    System.out.print("Invalid option entered......");
                    break;
            }
            //taking the user scanner to run the program again or to stop
			boolean value = true;
				while (value) {
                    System.out.println("M - Go back to Menu");
                    System.out.println("E - Exit");
					String select = scanner.next().toLowerCase();

					if (select.equals("m")) {
						break;
					}
					else if (select.equals("e")) {
						System.out.println("Program ends.........");
						System.exit(0);
					}
					else
						System.out.println("Enter input again");
						value = true;
				}
			cont = true;
        }
    }
}

