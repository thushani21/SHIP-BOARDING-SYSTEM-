import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.*;

public class Main {

    //initializing Global components
    public static Scanner scanner = new Scanner(System.in);
    public static Cabin[] cabins = new Cabin[13];
    public static String queue[] = new String[5];
    public static int index = 1;
	public static int expenses = 1;
	
    //method to initialize 12 cabins
    public static void initialise() {
        for (int x = 1; x < 13; x++) {
            cabins[x] = new Cabin("", new Passenger("", "", "", "", "", "", "", "", "", 0));
        }
        System.out.println("initialise");
    }

    //method to add passengers to cabins
    public static void add() {
        boolean c = false;
			do {
				System.out.print("\nEnter cabin number between (1-12): " );
				String no = scanner.next();
				
				try{
					index = Integer.parseInt(no);
					c = true;
				}
				catch(NumberFormatException e){
					System.out.println("Enter number between (1-12): ");
				}
			}
		while (!c);
            
			if (index > 0 && index < 13) {
				if (cabins[index].passenger.fName1.equals("") && cabins[index].passenger.fName2.equals("") && cabins[index].passenger.fName3.equals("")) {
					System.out.print("Enter the first name of the first passenger in cabin number :" + index + " :");  //It is checked if cabin is free before entering details
					cabins[index].passenger.fName1 = scanner.next().toUpperCase();
					System.out.print("Enter the last name of the first passenger in cabin number :" + index + " :");
					cabins[index].passenger.lName1 = scanner.next().toUpperCase();
					boolean cost1 = false;
						do {
							System.out.print("Enter expense :");
							cabins[index].passenger.expense1 = scanner.next();
							
							try{
								expenses = Integer.parseInt(cabins[index].passenger.expense1);      //It is ensured that only numbers are entered when expenses is asked
								cost1 = true;
							}
							catch(NumberFormatException e){
								System.out.println("Enter integers only.....");
							}
						}
					while (!cost1);
					cabins[index].passenger.totalExpense = Integer.parseInt(cabins[index].passenger.expense1);
							

					System.out.println("Do You want to add a second passenger to the cabin? Y or N");           //User is asked if another passenger should be added to the room
					String secondPassenger = scanner.next().toLowerCase();

					if(secondPassenger.equals("y")) {
						System.out.print("Enter the first name of the second passenger in cabin number :" + index + " :");
						cabins[index].passenger.fName2 = scanner.next().toUpperCase();
						System.out.print("Enter the last name of the second passenger in cabin number :" + index + " :");
						cabins[index].passenger.lName2 = scanner.next().toUpperCase();
						boolean cost2 = false;
						do {
							System.out.print("Enter expense :");  //Program checks if the desired Cabin is free before entering name, if not prints message
							cabins[index].passenger.expense2 = scanner.next();

							try{
								expenses = Integer.parseInt(cabins[index].passenger.expense2);
								cost2 = true;
							}
							catch(NumberFormatException e){
								System.out.println("Enter integers only.....");
							}
						}
						while (!cost2);
						cabins[index].passenger.totalExpense = Integer.parseInt(cabins[index].passenger.expense1)  + Integer.parseInt(cabins[index].passenger.expense2);


					}else if (secondPassenger.equals("n")){                 //If user enters 'n' program goes back to menu
						return;

					}
					System.out.println("Do You want to add a third passenger to the cabin? Y or N");
					String thirdPassenger = scanner.next().toLowerCase();

					if(thirdPassenger.equals("y")) {
						System.out.print("Enter the first name of the third passenger in cabin number :" + index + " :");  //Program checks if the desired Cabin is free before entering name, if not prints message
						cabins[index].passenger.fName3 = scanner.next().toUpperCase();
						System.out.print("Enter the last name of the third passenger in cabin number :" + index + " :");  //Program checks if the desired Cabin is free before entering name, if not prints message
						cabins[index].passenger.lName3 = scanner.next().toUpperCase();
						boolean cost3 = false;
						do {
							System.out.print("Enter expense :");  //Program checks if the desired Cabin is free before entering name, if not prints message
							cabins[index].passenger.expense3 = scanner.next();

							try{
								expenses = Integer.parseInt(cabins[index].passenger.expense3);
								cost3 = true;
							}
							catch(NumberFormatException e){
								System.out.println("Enter integers only.....");
							}
						}
						while (!cost3);
						cabins[index].passenger.totalExpense = Integer.parseInt(cabins[index].passenger.expense1)  + Integer.parseInt(cabins[index].passenger.expense2) + Integer.parseInt(cabins[index].passenger.expense3);

					}else if (thirdPassenger.equals("n")){
						return;
					}

					System.out.println("Passenger details added successfully");         //Message appears when passenger details are added
					}
					else {
						System.out.println("Cabin is already occupied");
                        queue();                // if cabins are already occupied, message appears and the queue method is called
					}
			}
			else{
				System.out.println("Enter Valid Cabin Number :");             //If user input is out index, message appears
			}
    }

    //method to view all cabin details
    public static void view() {
        for (int x = 1; x < cabins.length; x++) {
            System.out.println("Cabin " + x + " occupied by \n\n" + cabins[x].passenger.fName1 + " " + cabins[x].passenger.lName1 + "\n" + cabins[x].passenger.fName2 + " " + cabins[x].passenger.lName2 + "\n" + cabins[x].passenger.fName3 + " " + cabins[x].passenger.lName3 + "\n\n....................................");
        }
    }

    //method to delete passengers from cabins
    public static void delete() {
        int x = 0;
        System.out.println("Enter cabin number to delete :");
        int cabinNo = scanner.nextInt();            // user is asked for a cabin number to delete passenger details

        for (int i = 1; i < cabins.length; i++) {

            if (!(cabins[i].passenger.fName1.equals(""))) {   //Checks if there are empty cabins available
                x = x + 1;
            }
            if (i == cabinNo) {
                System.out.println(cabins[i].passenger.fName1 + " Staying in cabin Number " + i + " has been removed");  //Message appears when passengers are deleted from cabin and all passenger details are set to empty
                cabins[i].passenger.fName1 = "";
                cabins[i].passenger.fName2 = "";
                cabins[i].passenger.fName3 = "";

                cabins[i].passenger.lName1 = "";
                cabins[i].passenger.lName2 = "";
                cabins[i].passenger.lName3 = "";

                cabins[i].passenger.expense1 = "";
                cabins[i].passenger.expense2 = "";
                cabins[i].passenger.expense3 = "";

                cabins[i].passenger.totalExpense = 0;

                System.out.println("Deleted passenger from cabin " + i + " successfully");
            }
            if (x == 12) {
                String queueName = queue[1];            //name from waiting is list is taken when cabin becomes empty
                for ( int j = 1 ; j < queue.length-1 ; j ++) {
                    queue[j] = queue[j+1];
                }
                queue[queue.length-1] = null;
                cabins[cabinNo].passenger.fName1 = queueName;
                System.out.print("Enter the last name of the first passenger in cabin number :" + cabinNo + " :");           //all other details are taken from passenger
                cabins[cabinNo].passenger.lName1 = scanner.next().toUpperCase();
                boolean cost1 = false;
                do {
                    System.out.print("Enter expense :\n");
                    cabins[cabinNo].passenger.expense1 = scanner.next();

                    try{
                        expenses = Integer.parseInt(cabins[cabinNo].passenger.expense1);
                        cost1 = true;
                    }
                    catch(NumberFormatException e){
                        System.out.println("Enter integers only.....");
                    }
                }
                while (!cost1);
                cabins[cabinNo].passenger.totalExpense = Integer.parseInt(cabins[cabinNo].passenger.expense1);

                System.out.println("Do You want to add a second passenger to the cabin? Y or N");
                String secondPassenger = scanner.next().toLowerCase();

                if(secondPassenger.equals("y")) {
                    System.out.print("Enter the first name of the second passenger in cabin number :\n" + cabinNo + " :");
                    cabins[cabinNo].passenger.fName2 = scanner.next().toUpperCase();
                    System.out.print("Enter the last name of the second passenger in cabin number :\n" + cabinNo + " :");
                    cabins[cabinNo].passenger.lName2 = scanner.next().toUpperCase();
                    boolean cost2 = false;
                    do {
                        System.out.print("Enter expense :");
                        cabins[cabinNo].passenger.expense2 = scanner.next();

                        try{
                            expenses = Integer.parseInt(cabins[cabinNo].passenger.expense2);
                            cost2 = true;
                        }
                        catch(NumberFormatException e){
                            System.out.println("Enter integers only.....");
                        }
                    }
                    while (!cost2);
                    cabins[cabinNo].passenger.totalExpense = Integer.parseInt(cabins[cabinNo].passenger.expense1)  + Integer.parseInt(cabins[cabinNo].passenger.expense2);


                }else if (secondPassenger.equals("n")){
                    return;

                }
                System.out.println("Do You want to add a third passenger to the cabin? Y or N");
                String thirdPassenger = scanner.next().toLowerCase();

                if(thirdPassenger.equals("y")) {
                    System.out.print("Enter the first name of the third passenger in cabin number :" + cabinNo + " :");
                    cabins[cabinNo].passenger.fName3 = scanner.next().toUpperCase();
                    System.out.print("Enter the last name of the third passenger in cabin number :" + cabinNo + " :");
                    cabins[cabinNo].passenger.lName3 = scanner.next().toUpperCase();
                    boolean cost3 = false;
                    do {
                        System.out.print("Enter expense :");
                        cabins[cabinNo].passenger.expense3 = scanner.next();

                        try{
                            expenses = Integer.parseInt(cabins[cabinNo].passenger.expense3);
                            cost3 = true;
                        }
                        catch(NumberFormatException e){
                            System.out.println("Enter integers only.....");
                        }
                    }
                    while (!cost3);
                    cabins[cabinNo].passenger.totalExpense = Integer.parseInt(cabins[cabinNo].passenger.expense1)  + Integer.parseInt(cabins[cabinNo].passenger.expense2) + Integer.parseInt(cabins[cabinNo].passenger.expense3);

                }else if (thirdPassenger.equals("n")){
                    return;
                }

                System.out.println("Passenger details added successfully");     //Message appears once all passenger details are added
            }
        }
    }

    //method to view all empty cabins
    public static void empty() {
        int i = 0;
        for (int x = 1; x < cabins.length; x++) {
            if (cabins[x].passenger.fName1.equals("") && cabins[x].passenger.fName2.equals("") && cabins[x].passenger.fName3.equals("")) {  //checks which cabins are empty
                System.out.println("cabin " + x + " is empty");
            } else i++;
        }
        if (i == 12)
            System.out.println("There are no empty cabins");
    }

    //method to find passenger details
    public static void find() {
        System.out.print("Enter the passenger's first name :");         //Passenger's first name is asked to check which cabin he/she is in
        String passenger = scanner.next().toUpperCase();
        boolean isCustomer = false;
        for (int x = 1; x < cabins.length; x++) {
            if (cabins[x].passenger.fName1.equals(passenger) || cabins[x].passenger.fName2.equals(passenger) || cabins[x].passenger.fName3.equals(passenger)) {
                System.out.println(passenger + " is found in cabin number " + x);
                isCustomer = true;
                break;
            }
        }
        if (!isCustomer) {
            System.out.println("Passenger not available");          //If first name doesn't match with the existing details, message appears
        }
    }

    //method to create a text file and store cabin details
    public static void store() throws IOException {
        File Storage = new File("customerData.txt");            //Text file being created
        Storage.createNewFile();

        FileWriter writer = new FileWriter(Storage.getName());
        for (int x = 1; x < cabins.length; x++) {
            writer.write(cabins[x].passenger.fName1 + "\n");
            writer.write(cabins[x].passenger.lName1 + "\n");
            writer.write(cabins[x].passenger.expense1 + "\n");
            writer.write(cabins[x].passenger.fName2 + "\n");
            writer.write(cabins[x].passenger.lName2 + "\n");
            writer.write(cabins[x].passenger.expense2 + "\n");
            writer.write(cabins[x].passenger.fName3 + "\n");
            writer.write(cabins[x].passenger.lName3 + "\n");
            writer.write(cabins[x].passenger.expense3 + "\n");
			writer.write(cabins[x].passenger.totalExpense + "\n");
        }
        writer.close();
        System.out.println("File saved");           //Message appears once all data is saved
    }

    //method to load cabin details from text file
    public static void load() throws IOException {
        int index = 1;
        File Storage = new File("customerData.txt");            //created text file is called

        Scanner reader = new Scanner(Storage);
        while (reader.hasNextLine()) {
            String data = reader.nextLine();
            String data1 = reader.nextLine();
            String data2 = reader.nextLine();
			String data3 = reader.nextLine();
            String data4 = reader.nextLine();
            String data5 = reader.nextLine();
			String data6 = reader.nextLine();
            String data7 = reader.nextLine();
            String data8 = reader.nextLine();
			String data9 = reader.nextLine();
            cabins[index].passenger.fName1 = data;          // all data is stored back into arrays
            cabins[index].passenger.lName1 = data1;
            cabins[index].passenger.expense1 = data2;
			cabins[index].passenger.fName2 = data3;
            cabins[index].passenger.lName2 = data4;
            cabins[index].passenger.expense2 = data5;
			cabins[index].passenger.fName3 = data6;
            cabins[index].passenger.lName3 = data7;
            cabins[index].passenger.expense3 = data8;
			cabins[index].passenger.totalExpense = Integer.parseInt(data9);
            index++;
        }
        reader.close();
        System.out.println("Loaded successfully");  //Message appears once all data is loaded
    }

    //Method to view passenger names in alphabetical order
    public static void order() {
        for (int i = 1; i < cabins.length; i++) {
            for (int j = i + 1; j < cabins.length; j++) {
                if (cabins[i].passenger.fName1.compareTo(cabins[j].passenger.fName1) > 0) //compares two different elements of the array at a time
                {
                    String temp = cabins[i].passenger.fName1;
                    cabins[i].passenger.fName1 = cabins[j].passenger.fName1;
                    cabins[j].passenger.fName1 = temp;  //rearranged in a way to make sure it is in alphabetical order
                }
            }
        }
        for (int x = 1; x < cabins.length; x++) {
            if(!cabins[x].passenger.fName1.equals(""))
                System.out.println("-"+ cabins[x].passenger.fName1);
        }
    }

	//Method to print passenger expenses
    public static void viewExpenses() {
        for (int x = 1; x < cabins.length; x++) {
            System.out.println(cabins[x].passenger.fName1 + "    $" + cabins[x].passenger.expense1 + "\n" + cabins[x].passenger.fName2 + "    $" + cabins[x].passenger.expense2 + "\n" + cabins[x].passenger.fName3 + "    $" + cabins[x].passenger.expense3 );
			System.out.println("\nTotal Expense of Cabin " + x + " is $" + cabins[x].passenger.totalExpense + "\n\n----------------------------------------------------------");
        }
    }

    //method to print main menu and return user option
    public static String menu() {
        System.out.println("\n||||||||||||| Welcome to the Cruise ship |||||||||||||\n");
        System.out.println("A - Add new Passenger");
        System.out.println("E - Display Empty Cabins");
        System.out.println("V - View All Cabins");
        System.out.println("D - Delete Passenger From Cabin");
        System.out.println("F - Find cabin from customer name");
        System.out.println("S - Store program data into file");
        System.out.println("L - Load program data from file");
        System.out.println("O - View passengers ordered alphabetically by name");
        System.out.println("Q - End the program");
        System.out.println("T- View expenses");
        System.out.print("\n Select an option: ");
        String option = scanner.next().toLowerCase();

        return option;          //returns user input
    }

    //method to add passenger to waiting list
    public static void queue() {
        int x = 0;
        for (int i = 1; i < cabins.length; i++) {
            if (!(cabins[i].passenger.fName1.equals(""))) {         //Checks if there is any empty cabin available
                x = x + 1;
            }
        }
        if (x == 12) {
            System.out.println("Since All the cabins are Occupied You will be Added to the waiting list. \nPlease enter your first name to add in the waiting list: ");
            for(int i = 1; i < queue.length; i++)
                if(queue[i] == null) {
                    queue[i] = scanner.next().toUpperCase();
                    break;
                }
        }
    }

    public static void main(String[] args) {

        initialise();                //initialize method is called
        boolean cont = true;            //boolean to keep the program running until the user wants to stop
        while (cont) {
            String option = menu();

            switch (option) {
                case "v":
                    view();
                    break;
                case "e":
                    empty();
                    break;
                case "a":
                    add();
                    break;
                case "d":
                    delete();
                    break;
                case "f":
                    find();
                    break;
                case "s":
                    try {
                        store();
                    } catch (IOException e) {
                        e.printStackTrace();  //Method passed to manage exceptions and error
                    }
                    break;
                case "l":
                    try {
                        load(); //The method load is called
                    } catch (IOException e) {
                        e.printStackTrace();  //Method passed to manage exceptions and error
                    }
                    break;
                case "o":
                    order();
                    break;
				case "t":
                    viewExpenses();
                    break;
				case "q":
					System.out.println("Program ends.........");
                    System.exit(0);
                    break;
                default:                                //when the user enters something other than the options given
                    System.out.print("Invalid option entered......");
                    break;
            }
            //taking the user scanner to run the program again or to stop
			boolean runAgain = true;
				while (runAgain) {

				System.out.println("M - Go back to Menu");
				System.out.println("E - Exit");
				String select = scanner.next().toLowerCase();

				if (select.equals("m")) {
					break;
				}
				else if (select.equals("e")) {
					System.out.println("Program ends.........");
					System.exit(0);
				}
				else
					System.out.println("Enter input again");
					runAgain = true;
				}
			cont = true;
        }
    }
}
