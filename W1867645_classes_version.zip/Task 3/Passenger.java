public class Passenger {
    //variables for the customer details
    public String fName1;
	public String fName2;
	public String fName3;
    public String lName1;
	public String lName2;
	public String lName3;
    public String expense1;
	public String expense2;
	public String expense3;
	public int totalExpense;

    public Passenger(String fName1,String fName2,String fName3,String lName1,String lName2,String lName3,String expense1,String expense2,String expense3,int totalExpense) {
        this.fName1 = fName1;
		this.fName2 = fName2;
		this.fName3 = fName3;
        this.lName1 = lName1;
		this.lName2 = lName2;
		this.lName3 = lName3;
        this.expense1 = expense1;
		this.expense2 = expense2;
		this.expense3 = expense3;
		this.totalExpense = totalExpense;
    }
}
